# Install this profile on GitHub

1. Open https://github.com/nikkudeekshith/nikkudeekshith
2. Click **Add file → Upload files**.
3. Extract this ZIP on your computer first.
4. Upload the extracted files and folders, preserving their folder structure. If GitHub's browser upload is awkward with folders, use GitHub Desktop or VS Code to commit the extracted folder to the existing repository.
5. Commit the changes to the `main` branch.
6. Open the repository's **Actions** tab and run **Generate contribution snake** once using **Run workflow**. If prompted, enable Actions and allow workflow write access under Settings → Actions → General.
7. The radar charts are already included; the contribution snake appears after its workflow succeeds.

Repository name must remain `nikkudeekshith`.

## Customize your profile
- Edit `README.md` for text and layout.
- Edit `assets/skills.json` and `assets/langmix.json` to change radar-chart values. The values in these files are starter estimates; adjust them to match your actual skills.
- This template uses your known repositories `travora` and `OpsPilot-Agentic-AI`. Update their descriptions in `README.md` if needed.
