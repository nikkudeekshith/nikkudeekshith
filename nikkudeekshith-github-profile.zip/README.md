<div align="center">

<img src="assets/banner.svg" width="100%" alt="Nikku Deekshith developer profile banner" />

<a href="https://github.com/nikkudeekshith">
  <img src="https://readme-typing-svg.demolab.com?font=JetBrains+Mono&weight=600&size=22&duration=2800&pause=900&color=AA9BEF&center=true&vCenter=true&width=800&lines=Software+Developer+%7C+AI%2FML+Enthusiast;Exploring+Generative+AI+and+Agentic+Systems;Building+real-world+projects" alt="Typing introduction" />
</a>

<br/>

<a href="https://github.com/nikkudeekshith?tab=repositories"><img src="https://img.shields.io/badge/Repositories-Explore-7C3AED?style=for-the-badge&logo=github" alt="Repositories" /></a>
<a href="https://github.com/nikkudeekshith?tab=followers"><img src="https://img.shields.io/github/followers/nikkudeekshith?style=for-the-badge&color=2563eb&label=Followers" alt="Followers" /></a>
<img src="https://komarev.com/ghpvc/?username=nikkudeekshith&style=for-the-badge&color=7C3AED&label=PROFILE+VIEWS" alt="Profile views" />

</div>

---

## `01` / SYSTEM PROFILE

<table>
<tr>
<td width="38%" align="center" valign="middle">

<img src="https://skillicons.dev/icons?i=python,java,react,aws&perline=2" alt="Core technologies" />

**DEVELOPER PROFILE**

`CSE · KIIT UNIVERSITY`

`GRADUATING · 2027`

</td>
<td width="62%" valign="middle">

| SYSTEM INFO | DETAILS |
|:--|:--|
| **Identity** | Nikku Deekshith |
| **Primary Focus** | Software Development |
| **AI Division** | Machine Learning & Generative AI |
| **Web Division** | React.js & JavaScript |
| **Languages** | Python, Java, C, SQL |
| **Current Mission** | Build useful, real-world software |
| **Status** | Always learning and building |

</td>
</tr>
</table>

## `02` / ABOUT ME

Hi! I'm a Computer Science and Engineering student at **KIIT University**, graduating in 2027. I enjoy building applications and exploring how AI can solve practical problems.

- 💻 Interested in software development, AI/ML and full-stack development.
- 🤖 Exploring LLM applications, LangChain and agentic AI workflows.
- 🧠 Building my fundamentals in programming, databases and software engineering.
- 🚀 I learn best by building practical projects and improving them over time.

> **My philosophy:** Learn the fundamentals. Build consistently. Improve every day.

---

## `03` / SELECTED PROJECTS

<table>
<tr>
<td width="50%" valign="top">

### ✈️ Travora

A travel-planning project built with Python.

**Focus:** Travel planning and application development

[Explore repository →](https://github.com/nikkudeekshith/travora)

</td>
<td width="50%" valign="top">

### 🤖 OpsPilot-Agentic-AI

An AI-powered autonomous incident investigation and root cause analysis platform.

**Focus:** AI applications and incident analysis

[Explore repository →](https://github.com/nikkudeekshith/OpsPilot-Agentic-AI)

</td>
</tr>
</table>

---

## `04` / TECHNOLOGY MATRIX

<div align="center">

### PROGRAMMING LANGUAGES
<img src="https://skillicons.dev/icons?i=python,java,c,js,html,css" alt="Programming languages" />

### DEVELOPMENT & TOOLS
<img src="https://skillicons.dev/icons?i=react,nodejs,mysql,git,github,vscode,aws" alt="Development tools" />

### AI / DATA SCIENCE
`Pandas` · `NumPy` · `Scikit-learn` · `TensorFlow` · `OpenCV` · `LangChain` · `OpenAI API`

</div>

---

## `05` / SIGNALS

<div align="center">

<table>
<tr>
<td width="50%" align="center">

**SKILL RADAR**

<img src="assets/radar-dark.svg" width="100%" alt="Software development skill radar" />

</td>
<td width="50%" align="center">

**TECHNOLOGY FOCUS**

<img src="assets/radar-langs-dark.svg" width="100%" alt="Technology focus radar" />

</td>
</tr>
</table>

<sub>Radar values are editable estimates, not measured test results. Update `assets/skills.json` and `assets/langmix.json` as your skills grow.</sub>

</div>

---

## `06` / GITHUB TELEMETRY

<div align="center">

<img width="49%" src="https://github-readme-stats.vercel.app/api?username=nikkudeekshith&show_icons=true&theme=tokyonight&hide_border=true&bg_color=0D1117&title_color=A78BFA&icon_color=58A6FF" alt="GitHub statistics" />
<img width="49%" src="https://github-readme-stats.vercel.app/api/top-langs/?username=nikkudeekshith&layout=compact&theme=tokyonight&hide_border=true&bg_color=0D1117&title_color=A78BFA" alt="Most used languages" />

<br/>

<img width="70%" src="https://streak-stats.demolab.com?user=nikkudeekshith&theme=tokyonight&hide_border=true&background=0D1117&ring=A78BFA&fire=58A6FF&currStreakLabel=A78BFA" alt="GitHub contribution streak" />

</div>

---

## `07` / CONTRIBUTION FLOW

<div align="center">

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://raw.githubusercontent.com/nikkudeekshith/nikkudeekshith/output/github-contribution-grid-snake-dark.svg">
  <source media="(prefers-color-scheme: light)" srcset="https://raw.githubusercontent.com/nikkudeekshith/nikkudeekshith/output/github-contribution-grid-snake.svg">
  <img alt="GitHub contribution snake animation" src="https://raw.githubusercontent.com/nikkudeekshith/nikkudeekshith/output/github-contribution-grid-snake.svg">
</picture>

<sub>The animation appears after the contribution-snake workflow runs successfully.</sub>

</div>

---

## `08` / CONNECT

<div align="center">

<a href="https://github.com/nikkudeekshith"><img src="https://img.shields.io/badge/GITHUB-161B22?style=for-the-badge&logo=github&logoColor=white" alt="GitHub" /></a>
<a href="https://www.linkedin.com/"><img src="https://img.shields.io/badge/LINKEDIN-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn" /></a>

<br/><br/>

`BUILD · LEARN · ITERATE`

*Thanks for visiting my digital workspace.*

</div>
